# CrashVPN

For install use the command

apt-get update -y && apt-get upgrade -y && wget https://raw.githubusercontent.com/Penguinehis/CrashVPN/main/crashvpn && chmod 777 crashvpn && ./crashvpn