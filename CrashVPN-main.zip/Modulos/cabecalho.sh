#!/bin/bash
clear